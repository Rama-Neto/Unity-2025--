using UnityEngine;

public class Enemy : MonoBehaviour
{
    //Variables de vida, persecuci�n y cono de visi�n, expuestas en Inspector
    public int enemyLife = 50;
    public float chaseSpeed = 5f;
    [Header("Vision Settings")]
    public float visionRange = 10f;
    public float visionAngle = 60f;

    private Transform player; //referencia al transform del player, para persecuci�n
    private Vector3 spawnPoint; //punto de respawn espec�fico del enemigo
    private string state = "Normal"; //Estado de arranque del enemigo
    private bool isDead = false; //booleano para chequear si el enemigo est� vivo o muerto

    private float staminaTimer = 0f; //timer para drenaje y regeneraci�n de estamina del player, seg�n si est� dentro o fuera de cono de visi�n

    private void Start()
    {
        player = GameObject.FindWithTag("Player").transform;
        spawnPoint = transform.position;
        SetState("Normal");
    }

    //Input F3 para respawn de enemigo si el booleano isDead es true
    private void Update()
    {
        if (isDead)
        {
            if (Input.GetKeyDown(KeyCode.F3))
            {
                Respawn();
                Debug.Log("Enemy respawning");
            }
            return;
        }

        float distance = Vector3.Distance(transform.position, player.position);
        Vector3 dirToPlayer = (player.position - transform.position).normalized;

        //Se persigue al jugador cuando est� dentro del rango y �ngulo de visi�n (cono), de lo contrario el estado sigue siendo Normal y el player puede regenerar estamina
        float angleToPlayer = Vector3.Angle(transform.forward, dirToPlayer);

        if (distance <= visionRange && angleToPlayer <= visionAngle / 2f)
        {
            ChasePlayer();
        }
        else
        {
            SetState("Normal");
            RegenerateStamina();
        }

    }

    //L�gica de persecusi�n a player, contiene drenaje de estamina del player (1 por segundo mientras est� en cono de visi�n)
    void ChasePlayer()
    {
        SetState("Chase");
        Vector3 dir = (player.position - transform.position).normalized;
        transform.position += dir * chaseSpeed * Time.deltaTime;

        // Drain stamina at 1 point per second
        staminaTimer += Time.deltaTime;
        if (staminaTimer >= 1f)
        {
            PlayerController pc = player.GetComponent<PlayerController>();
            if (pc != null && pc.playerStamina > 0)
            {
                pc.playerStamina = Mathf.Max(0, pc.playerStamina - 1);
            }
            staminaTimer = 0f;
            Debug.Log("Player Stamina: " + pc.playerStamina);
        }
    }

    void RegenerateStamina()
    {
        //Player regenera estamina, 1 por segundo
        staminaTimer += Time.deltaTime;
        if (staminaTimer >= 1f)
        {
            PlayerController pc = player.GetComponent<PlayerController>();
            if (pc != null && pc.playerStamina < 10)
            {
                pc.playerStamina = Mathf.Min(10, pc.playerStamina + 1);
            }
            staminaTimer = 0f;
            Debug.Log("Player Stamina: " + pc.playerStamina);
        }
    }

    //L�gica de da�o que recibe el enemigo
    public void TakeDamage(int damage)
    {
        if (isDead) return;

        enemyLife -= damage;
        SetState("Damaged");

        if (enemyLife <= 0)
        {
            Die();
        }
    }

    //L�gica de muerte del enemigo, se apagan sus componentes de renderizaci�n y colisi�n
    public void Die()
    {
        SetState("Dead");
        isDead = true;

        // Disable visuals and collisions
        GetComponent<Renderer>().enabled = false;
        GetComponent<Collider>().enabled = false;
    }

    //L�gica de respawn del enemigo, se vuelven a mostrar sus componentes de renderizaci�n y colisi�n
    void Respawn()
    {
        transform.position = spawnPoint;
        enemyLife = 50;
        isDead = false;

        // Re-enable visuals and collisions
        GetComponent<Renderer>().enabled = true;
        GetComponent<Collider>().enabled = true;

        SetState("Normal");
    }

    //Muestra el estado del enemigo en Consola
    void SetState(string newState)
    {
        if (state != newState)
        {
            state = newState;
            Debug.Log("Enemy State: " + state);
        }
    }

    //Gizmos dibujados en scene view para poder ver el cono de visi�n
    private void OnDrawGizmos()
    {
        // Draw cone even in edit mode
        Gizmos.color = Color.yellow;

        // Draw vision range sphere
        Gizmos.DrawWireSphere(transform.position, visionRange);

        // Cone boundaries
        Quaternion leftRot = Quaternion.Euler(0, -visionAngle / 2f, 0);
        Vector3 leftDir = leftRot * transform.forward * visionRange;
        Gizmos.DrawLine(transform.position, transform.position + leftDir);

        Quaternion rightRot = Quaternion.Euler(0, visionAngle / 2f, 0);
        Vector3 rightDir = rightRot * transform.forward * visionRange;
        Gizmos.DrawLine(transform.position, transform.position + rightDir);

        // Forward direction
        Gizmos.color = Color.red;
        Gizmos.DrawLine(transform.position, transform.position + transform.forward * visionRange);
    }


}





